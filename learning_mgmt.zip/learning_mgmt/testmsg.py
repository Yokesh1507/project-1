import pywhatkit as kit

# Send a message (phone number, message, hour, minute)
kit.sendwhatmsg("+919600718716", "Hello from Python!", 14, 30)
